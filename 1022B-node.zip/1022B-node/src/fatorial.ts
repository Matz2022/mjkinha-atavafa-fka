function calcularFatorial(a:number):number{
    let res = a;
    if (a === 0  || a ===1)
        return 1

    while (a>1){
        a--;
        res= res*a
    }
    return res
}

export {calcularFatorial}