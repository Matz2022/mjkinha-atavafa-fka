function encontrarMenorNumero(a:number,b:number,c:number,d:number,e:number):number{
    
}