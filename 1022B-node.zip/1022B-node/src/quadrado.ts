function calcularQuadrado(a:number):number{
    return a*a
}
export{calcularQuadrado}