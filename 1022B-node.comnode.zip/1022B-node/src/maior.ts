
function calcularMaior(a:number, b:number):number{
  if (a >b){
    return a;
  } else{
    return b;
  }
}
export {calcularMaior}
