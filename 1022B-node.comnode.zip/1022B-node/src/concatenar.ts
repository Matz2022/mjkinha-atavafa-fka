function concatenarStrings(str1:string, str2:string):string{
  return str1 + str2;
}
export {concatenarStrings}