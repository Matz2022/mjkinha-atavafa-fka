function encontrarMenorNumero(numeros:number[]):number{
    if(numeros === 0 ){
     return 0;
    }
     let menor = numeros[0];

     for (let i = 1; i< numeros; i++) {
        if (numeros[i] < menor){
            menor = numeros[i]
     }
     }
    return menor;

export {encontrarMenorNumero}